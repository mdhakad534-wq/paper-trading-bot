# Paper Trading Bot (standalone build)

A mobile-first, AI-assisted crypto **paper trading** simulator. Virtual money
only — no real orders, no exchange keys with trading permission required.
This is the same app built across the original 10-phase conversation, packaged
to run on your own machine instead of inside Claude's chat artifact sandbox
(which blocks outbound network calls to exchanges entirely — that's why it
showed "Failed to fetch" there).

## Quick start

```bash
npm install
npm run dev
```

Then open the URL Vite prints (usually `http://localhost:5173`).

## The data source story (read this once)

Getting real, CORS-friendly, free crypto market data turned out to be a real
journey, and it's worth knowing what happened in case something breaks later:

1. **Binance** (`api.binance.com`) — geo-blocked for US connections at the
   network level, *and* has a long history of not sending CORS headers for
   direct browser requests even outside the US. Dead end two ways.
2. **CryptoCompare** (`min-api.cryptocompare.com`) — was acquired by CoinDesk
   in late 2024, rebranded, and had its free keyless tier restructured through
   2025–2026. What used to be genuinely free-and-keyless no longer reliably is.
3. **Kraken** (`api.kraken.com`) — what this app actually uses. A real
   exchange, not geo-blocked for US users, no key required for public market
   data, and its interval options (1/5/15/30/60/240 minutes) map exactly onto
   the app's 5m/15m/1h/4h timeframes.

**One real limitation to know about**: Kraken's public OHLC endpoint only
ever returns the most recent ~720 candles, with no way to page further into
the past ("older data cannot be retrieved, regardless of the value of since"
— their own docs). That's plenty for live trading and indicators (which only
need ~210 candles of warm-up), but it caps how far back a backtest can
usefully go on fast timeframes — that's why the Backtest and Strategy Lab
date-range options are capped at 1–2 days instead of a longer window. If you
want deeper backtests later, that needs either a different data source for
historical candles specifically, or a paid tier from an exchange/vendor that
offers real pagination.

If Kraken ever breaks for you (rate limits, an outage, another CORS
surprise), the error will show up specifically in the app's "STALE DATA"
banner or the Backtest/Strategy Lab error box — tell me the exact text and
I'll adjust rather than guessing at a fourth provider blind.

## Strategy Lab

Settings → **Open Strategy Lab** lets you backtest four different strategy
presets (Balanced, Conservative, Aggressive, Momentum-focused) against the
*same* historical data and compare win rate, return, profit factor, and max
drawdown side by side. Activating a preset is always a manual tap — nothing
ever switches automatically, matching how the original spec required any
strategy change to be proposed, backtested, validated, and only then
activated by a person. The currently active preset drives both the live
paper trading engine and the single-strategy Backtest tool.

## Enabling the AI confirmation layer (optional)

The bot works fully on the rule-based strategy engine with no setup. To also
get Claude's confirmation/veto step on top of it:

1. Get an API key at [console.anthropic.com](https://console.anthropic.com).
2. Open the app → **Settings** → **AI configuration** → paste the key → **Save key**.

The key is stored in this browser's `localStorage` on your machine only, and
is sent only to `api.anthropic.com` (with the
`anthropic-dangerous-direct-browser-access` header, which is what lets a
browser call the API directly instead of through a server). Without a key,
trades still happen — just on the rule engine alone, with no AI veto step.

**Do not deploy this publicly with a key wired in this way.** Calling the
Anthropic API directly from the browser means the key is visible to anyone
who opens devtools on the page. That's an acceptable tradeoff for running
this yourself locally. If you want to put this on a public URL (Vercel,
Netlify, etc.) and keep the AI layer, add a small serverless function that
holds the key server-side and proxies the request instead.

## Project structure

```
src/App.jsx        -- the entire app (all phases live in this one file)
src/main.jsx        -- React entry point
src/index.css        -- Tailwind directives
tailwind.config.js, postcss.config.js, vite.config.js -- build tooling
```

## What's still simulation-only, on purpose

- **No real exchange order execution anywhere.** The `exchangeAdapter` in
  `App.jsx` is an intentional stub that always throws — see Settings →
  Exchange connection for the reasoning. Wiring a real (even testnet)
  exchange needs a backend to hold the API secret and sign requests, which
  is a different kind of project than a static front-end.
- **Backtests and the Strategy Lab** fetch real historical candles but still
  only ever simulate — no orders are placed there either.
- **Indian stock market (NSE/BSE) support does not exist yet.** Crypto
  exchanges offer free, keyless, CORS-friendly public data, which is why this
  app could be built the way it is. Indian equities generally require a
  broker API (Zerodha Kite Connect, Upstox, Angel One, etc.) with an account
  and API key, plus different market-hours logic (NSE trades 9:15am–3:30pm
  IST, not 24/7 like crypto) — it's a genuinely separate build, not a
  drop-in data-source swap.

## Troubleshooting

- **Blank page / build errors on `npm run dev`**: make sure you're on
  Node.js 18+ (`node --version`), then delete `node_modules` and
  `package-lock.json` and re-run `npm install`.
- **Tailwind classes not applying**: confirm `tailwind.config.js`'s
  `content` array matches your file layout (it's already set to
  `./src/**/*.{js,jsx}`, which covers `App.jsx`).
- **Prices load once then stop, or a CORS error in the console**: check the
  exact error text — if Kraken itself is failing, tell me the message and
  I'll adjust rather than guessing.
- **"Not enough history" errors in Backtest/Strategy Lab**: you're likely
  asking for more days than Kraken's 720-candle cap can supply on 5-minute
  bars — use the 1-day option, or a symbol/timeframe pair with a longer
  history relative to its candle size.
